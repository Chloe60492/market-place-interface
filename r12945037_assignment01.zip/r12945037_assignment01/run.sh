#!/bin/bash

echo "Running the Marketplace CLI application..."
python3 main.py "$@"